# FF Toolkit

Android Studio project for a small process-diagnostics app. It lists only `/proc` entries Android permits the app to read and displays `/proc/self/maps` for its own process. Android's sandbox normally prevents reading other apps' process memory.

## Build APK

1. Open this folder in Android Studio (JDK 17 recommended).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. In the project root run:

   `gradle assembleDebug`

4. APK output: `app/build/outputs/apk/debug/app-debug.apk`

Install using Android platform-tools:

`adb install -r app/build/outputs/apk/debug/app-debug.apk`

## Build automatically in GitHub Actions

This project includes `.github/workflows/android.yml`. Upload the project to a GitHub repository, open **Actions**, choose **Build FF Toolkit APK**, and select **Run workflow**. When the run succeeds, download the `FFToolkit-debug-apk` artifact from the run's **Artifacts** section. This environment does not contain Android SDK/Gradle, so the APK is not prebuilt here.
