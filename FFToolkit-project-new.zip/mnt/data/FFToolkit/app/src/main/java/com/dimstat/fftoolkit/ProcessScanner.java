package com.dimstat.fftoolkit;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class ProcessScanner {
    public List<String> listProcesses() {
        List<String> out = new ArrayList<>();
        File[] entries = new File("/proc").listFiles();
        if (entries == null) return out;

        for (File entry : entries) {
            if (!entry.isDirectory() || !entry.getName().matches("\\d+")) continue;
            File cmdline = new File(entry, "cmdline");
            try (BufferedReader reader = new BufferedReader(new FileReader(cmdline))) {
                String line = reader.readLine();
                if (line != null && !line.isEmpty()) {
                    line = line.replace('\0', ' ').trim();
                    if (!line.isEmpty()) out.add(entry.getName() + "  " + line);
                }
            } catch (IOException ignored) {
                // Android может запрещать чтение записи другого процесса.
            }
        }
        return out;
    }
}
