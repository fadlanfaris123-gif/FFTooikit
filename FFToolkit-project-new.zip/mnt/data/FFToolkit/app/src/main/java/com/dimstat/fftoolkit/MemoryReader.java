package com.dimstat.fftoolkit;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/** Чтение карты памяти только собственного процесса приложения. */
public final class MemoryReader {
    private MemoryReader() {}

    public static String readOwnMaps() throws IOException {
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/self/maps"))) {
            String line;
            while ((line = reader.readLine()) != null) result.append(line).append('\n');
        }
        return result.toString();
    }
}
