package com.dimstat.fftoolkit;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.IOException;

public class MainActivity extends Activity {
    private TextView log;
    private ProcessScanner scanner;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        scanner = new ProcessScanner();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        root.setPadding(pad, dp(28), pad, pad);

        TextView title = new TextView(this);
        title.setText("Dimstat FF Toolkit v1.0");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(18));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        Button scan = new Button(this);
        scan.setText("Сканировать доступные процессы");
        scan.setOnClickListener(v -> doScan());
        root.addView(scan, new LinearLayout.LayoutParams(-1, -2));

        Button maps = new Button(this);
        maps.setText("Прочитать карты памяти приложения");
        maps.setOnClickListener(v -> dumpMaps());
        root.addView(maps, new LinearLayout.LayoutParams(-1, -2));

        log = new TextView(this);
        log.setTextSize(12);
        log.setTextIsSelectable(true);
        log.setPadding(0, dp(16), 0, 0);
        log.setText("Готов к работе.\nAndroid ограничивает доступ к процессам других приложений.\n");
        ScrollView scroll = new ScrollView(this);
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void doScan() {
        log.append("\n[SCAN] Доступные записи /proc:\n");
        for (String process : scanner.listProcesses()) log.append("  " + process + "\n");
        log.append("[SCAN] Готово. Список ограничен правами Android.\n");
    }

    private void dumpMaps() {
        log.append("\n[/proc/self/maps]\n");
        try {
            String[] lines = MemoryReader.readOwnMaps().split("\\n");
            for (int i = 0; i < Math.min(lines.length, 30); i++) log.append("  " + lines[i] + "\n");
        } catch (IOException e) {
            log.append("  ERR: " + e.getMessage() + "\n");
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
